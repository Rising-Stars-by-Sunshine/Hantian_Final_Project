Dear llncs user,

The files in this directory belong to the LaTeX2e package
for Springer's Lecture Notes in Computer Science (LNCS) and
other proceedings book series.

It consists of the following files:

  readme.txt         this file
  
  main.tex           the paper
  fig1.png           a figure used in the paper
  m4 q2_1.png        a figure used in the paper

  llncsdoc.pdf       the documentation of the class (PDF version)

  splncs04.bst       current LNCS BibTeX style with alphabetic sorting
